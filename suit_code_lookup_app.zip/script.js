function searchSuit() {
  const input = document.getElementById("suitCodeInput").value.trim().toUpperCase();
  const resultArea = document.getElementById("result");

  if (input === "") {
    resultArea.innerHTML = "<p>Please enter a suit code.</p>";
    return;
  }

  const imagePath = `suits/${input}.jpg`;

  resultArea.innerHTML = `
    <p>You searched for: <strong>${input}</strong></p>
    <img src="${imagePath}" alt="Suit Image" onerror="handleNotFound()" />
    <br/>
    <a class="whatsapp-btn" href="https://wa.me/91XXXXXXXXXX?text=Hi, I'm interested in suit code ${input}" target="_blank">📲 Order on WhatsApp</a>
  `;
}

function handleNotFound() {
  document.getElementById("result").innerHTML = "<p>❌ No stitched look found for this code.</p>";
}
